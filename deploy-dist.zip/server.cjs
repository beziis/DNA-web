var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server/index.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
var distPath = import_path.default.resolve(process.cwd(), "dist");
var app = (0, import_express.default)();
var PORT = Number(process.env.PORT || 3e3);
app.disable("x-powered-by");
app.use(import_express.default.json({ limit: "1mb" }));
app.use(import_express.default.urlencoded({ extended: false, limit: "1mb" }));
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});
app.post("/api/analyze-data", (req, res) => {
  const { dataSummary } = req.body ?? {};
  if (typeof dataSummary !== "string" || !dataSummary.trim()) {
    return res.status(400).json({
      error: "Invalid request",
      message: "dataSummary is required and must be a non-empty string."
    });
  }
  return res.status(501).json({
    error: "AI analysis unavailable",
    message: "The analyze-data endpoint requires an external AI service, which has been removed from this deployment."
  });
});
app.use(import_express.default.static(distPath));
app.get("*", (_req, res) => {
  res.sendFile(import_path.default.join(distPath, "index.html"));
});
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Backend is running on port ${PORT}`);
});
//# sourceMappingURL=server.cjs.map
